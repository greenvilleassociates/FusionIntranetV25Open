ALTER TABLE "#__template_styles" ALTER COLUMN "home" TYPE character varying(7);
ALTER TABLE "#__template_styles" ALTER COLUMN "home" SET DEFAULT '0';
